package com.example.squadup.utils

import android.content.Context
import android.widget.Toast

fun Context.showShortToast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun Context.createShortToast(msg: String): Toast {
    return Toast.makeText(this, msg, Toast.LENGTH_SHORT)
}