package com.example.squadup.presentation.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.squadup.databinding.FragmentLoginBinding
import com.example.squadup.presentation.main.MainActivity
import com.example.squadup.utils.showShortToast
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.ActionCodeSettings
import com.google.firebase.auth.FirebaseAuth

class LoginFragment : Fragment() {

    private lateinit var binding: FragmentLoginBinding
    private val authInstance = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentLoginBinding.inflate(inflater, container, false).also { binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.run {
            btnSignUp.setOnClickListener { findNavController().navigate(LoginFragmentDirections.actionGlobalSignUpFragment()) }

            btnLogin.setOnClickListener {
                val email = etEmail.text.toString()
                val password = etPassword.text.toString()
                login(email, password)
            }
        }
    }

    private fun login(email: String, password: String) {
        if (isNotValidInputData(email, password)) return
        authInstance.signInWithEmailAndPassword(email, password).addOnSuccessListener {
            it.user?.let {
                if (it.isEmailVerified) {
                    val intent = Intent(requireContext(), MainActivity::class.java)
                    startActivity(intent)
                    requireActivity().finish()
                } else {
                    it.sendEmailVerification().addOnSuccessListener {
                        requireContext().showShortToast("verification code sent to email")
                    }.addOnFailureListener { e ->
                        requireContext().showShortToast("error: ${e.message}")
                    }
                }
            }
        }.addOnFailureListener { e ->
            Log.d("DEBUG", "login error = ${e.message}")
            requireContext().showShortToast("login error = ${e.message}")
        }

    }

    private fun isNotValidInputData(
        email: String,
        password: String,
    ): Boolean {
        if (email.isBlank()) {
            Log.d("DEBUG", "email is empty")
            requireContext().showShortToast("email is empty");return true
        }
        if (password.isBlank()) {
            Log.d("DEBUG", "password is empty")
            requireContext().showShortToast("password is empty");return true
        }
        return false
    }

}