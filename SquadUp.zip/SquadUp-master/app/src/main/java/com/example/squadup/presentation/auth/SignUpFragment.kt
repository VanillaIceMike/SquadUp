package com.example.squadup.presentation.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.squadup.databinding.FragmentSignupBinding
import com.example.squadup.presentation.main.MainActivity
import com.example.squadup.utils.showShortToast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest

class SignUpFragment : Fragment() {

    private lateinit var binding: FragmentSignupBinding
    private val authInstance = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentSignupBinding.inflate(inflater, container, false).also { binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.run {
            btnLogin.setOnClickListener { goToLoginFragment() }

            btnSignUp.setOnClickListener {
                val email = etEmail.text.toString()
                val name = etName.text.toString()
                val password = etPassword.text.toString()
                val passwordConfirm = etPasswordConfirm.text.toString()
                signUpUser(email, name, password, passwordConfirm)
            }
        }

    }

    private fun goToLoginFragment() {
        findNavController().navigate(SignUpFragmentDirections.actionGlobalLoginFragment())
    }

    private fun signUpUser(
        email: String,
        name: String,
        password: String,
        passwordConfirm: String
    ) {
        if (isNotValidInputData(email, name, password, passwordConfirm)) return
        createUser(email, password, name)
    }

    private fun createUser(email: String, password: String, name: String) {
        authInstance.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                result.user?.let { user ->
                    setNewName(name, user)
                    if (user.isEmailVerified) {
                        goToMainScreen()
                    } else {
                        user.sendEmailVerification().addOnSuccessListener {
                            requireContext().showShortToast("verification code sent to email")
                            goToLoginFragment()
                        }.addOnFailureListener { e ->
                            requireContext().showShortToast("error: ${e.message}")
                        }
                    }
                }
            }.addOnFailureListener { e ->
                requireContext().showShortToast(e.message.toString())
            }
    }


    private fun setNewName(name: String, user: FirebaseUser) {
        val userChanges = UserProfileChangeRequest.Builder().apply {
            displayName = name
        }
        user.updateProfile(userChanges.build()).addOnSuccessListener {

        }.addOnFailureListener {
            Log.d("DEBUG", "error profile was not updated")
            requireContext().showShortToast("something went wrong and username can`t be saved")
        }
    }

    private fun goToMainScreen() {
        val intent = Intent(requireContext(), MainActivity::class.java)
        startActivity(intent)
        requireActivity().finish()
    }

    private fun isNotValidInputData(
        email: String,
        name: String,
        password: String,
        passwordConfirm: String
    ): Boolean {
        if (email.isBlank()) {
            Log.d("DEBUG", "email is empty")
            requireContext().showShortToast("email is empty");return true
        }
        if (name.isBlank()) {
            Log.d("DEBUG", "name is empty")
            requireContext().showShortToast("name is empty");return true
        }
        if (password.isBlank()) {
            Log.d("DEBUG", "password is empty")
            requireContext().showShortToast("password is empty");return true
        }
        if (passwordConfirm.isBlank()) {
            Log.d("DEBUG", "password confirmation is empty")
            requireContext().showShortToast("password confirmation is empty");return true
        }
        if (password != passwordConfirm) {
            Log.d("DEBUG", "passwords are not the same")
            requireContext().showShortToast("passwords are not the same");return true
        }
        return false
    }
}